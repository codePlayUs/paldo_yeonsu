package org.sample.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.sample.domain.BoardVO;
import org.sample.domain.Criteria;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({
    "file:src/main/webapp/WEB-INF/spring/appServlet/servlet-context.xml",
    "file:src/main/webapp/WEB-INF/spring/root-context.xml"
})
@WebAppConfiguration
@Log4j
public class BoardControllerTests {

    @Autowired
    private WebApplicationContext ctx;

    private MockMvc mockMvc;

    @Before
    public void setup() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(ctx).build();
    }

    // 전체 게시글 목록 조회 테스트
    @Test
    public void testList() throws Exception {
        log.info(
            mockMvc.perform(get("/board/list")
                .param("pageNum", "1")
                .param("amount", "10"))
                .andExpect(status().isOk())
                .andReturn()
                .getModelAndView()
                .getModelMap()
        );
    }

    // 게시글 작성 페이지 GET 요청 테스트
    @Test
    public void testRegisterGet() throws Exception {
        mockMvc.perform(get("/board/register"))
            .andExpect(status().isOk());
    }

    // 게시글 등록 POST 테스트
    @Test
    public void testRegisterPost() throws Exception {
        String resultPage = mockMvc.perform(post("/board/register")
                .param("title", "테스트 제목")
                .param("content", "테스트 내용")
                .param("writer", "테스터"))
            .andExpect(status().is3xxRedirection())
            .andReturn()
            .getModelAndView()
            .getViewName();

        log.info("register POST 리다이렉트 페이지: " + resultPage);
    }

    // 게시글 상세 조회(GET) 테스트
    @Test
    public void testGet() throws Exception {
        log.info(
            mockMvc.perform(get("/board/get")
                .param("boardid", "1"))
                .andExpect(status().isOk())
                .andReturn()
                .getModelAndView()
                .getModelMap()
        );
    }

    // 게시글 수정 페이지 GET 테스트
    @Test
    public void testModifyGet() throws Exception {
        mockMvc.perform(get("/board/modify")
                .param("boardid", "1"))
            .andExpect(status().isOk());
    }

    // 게시글 수정 POST 테스트
    @Test
    public void testModifyPost() throws Exception {
        String resultPage = mockMvc.perform(post("/board/modify")
                .param("boardid", "1")
                .param("title", "수정된 제목")
                .param("content", "수정된 내용")
                .param("writer", "수정자"))
            .andExpect(status().is3xxRedirection())
            .andReturn()
            .getModelAndView()
            .getViewName();

        log.info("modify POST 리다이렉트 페이지: " + resultPage);
    }

    // 게시글 삭제 POST 테스트
    @Test
    public void testRemovePost() throws Exception {
        String resultPage = mockMvc.perform(post("/board/remove")
                .param("boardid", "1"))
            .andExpect(status().is3xxRedirection())
            .andReturn()
            .getModelAndView()
            .getViewName();

        log.info("remove POST 리다이렉트 페이지: " + resultPage);
    }

    // 브랜드별 게시글 목록 테스트 - 애플
    @Test
    public void testGetAppleList() throws Exception {
        mockMvc.perform(get("/board/apple"))
            .andExpect(status().isOk());
    }

    // 브랜드별 게시글 목록 테스트 - 삼성
    @Test
    public void testGetSamsungList() throws Exception {
        mockMvc.perform(get("/board/samsung"))
            .andExpect(status().isOk());
    }

    // 브랜드별 게시글 목록 테스트 - 소니
    @Test
    public void testGetSonyList() throws Exception {
        mockMvc.perform(get("/board/sony"))
            .andExpect(status().isOk());
    }

    // 브랜드별 게시글 목록 테스트 - 기타
    @Test
    public void testGetOtherList() throws Exception {
        mockMvc.perform(get("/board/others"))
            .andExpect(status().isOk());
    }
}
